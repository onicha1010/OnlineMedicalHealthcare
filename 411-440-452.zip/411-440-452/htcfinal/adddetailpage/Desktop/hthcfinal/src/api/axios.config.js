export const option = {
  headers: {
    "Content-Type": "application/json",
  },
};
