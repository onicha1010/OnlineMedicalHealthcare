export const NewsMock = [
  {
    id: 1,
    title: "News",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 2,
    title: "News",
    description: "Lorem ipsum dolor sit amet ",
    publishDate: "2020-12-12",
  },
  {
    id: 3,
    title: "News",
    description:
      "Lorem ipsum dolor sit amet . Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 4,
    title: "News",
    description:
      "Lorem ipsum dolor  ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 5,
    title: "News",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    title: "News News News NewsNewsNewsvNews",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    title: "NewsNewsNewsNews NewsNewsNews NewsNewsNews NewsNewsNews ",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
];
