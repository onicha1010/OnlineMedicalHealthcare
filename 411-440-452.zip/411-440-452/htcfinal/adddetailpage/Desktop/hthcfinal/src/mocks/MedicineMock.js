export const MedicineMock = [
  {
    id: 1,
    title: "Medicine",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 2,
    title: "Medicine",
    description: "Lorem ipsum dolor sit amet ",
    publishDate: "2020-12-12",
  },
  {
    id: 3,
    title: "Medicine",
    description:
      "Lorem ipsum dolor sit amet . Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 4,
    title: "Medicine",
    description:
      "Lorem ipsum dolor  ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    id: 5,
    title: "Medicine",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    title:
      "Medicine Medicine Medicine Medicine Medicine Medicine Medicine MedicineMedicine ",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
  {
    title:
      "Medicine Medicine Medicine Medicine Medicine Medicine Medicine MedicineMedicine ",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut? Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, eum dignissimos praesentium repellendus ratione ipsa quibusdam veritatis vel tempora, architecto aut ea, quae quos! Optio doloribus ipsam soluta aperiam aut?",
    publishDate: "2020-12-12",
  },
];
