create schema project;


create table admin(
	admin_ID int not null auto_increment primary key,
    admin_name  varchar(255) not null,
    admin_Email varchar(255) not null unique key,
    admin_Password varchar(255) not null
    );
    
create table news(
	news_ID int not null auto_increment primary key,
    news_name varchar(255) not null,
    news_author varchar(255) not null,
    news_detail text not null,
    news_created_at timestamp not null default current_timestamp,
    news_update_at timestamp not null default current_timestamp on update current_timestamp,
    admin_ID int not null,
    foreign key(admin_ID) references admin(admin_ID)
);


create table medicine(
	med_ID int not null auto_increment primary key,
    med_name varchar(255) not null,
    med_author varchar(255) not null,
    med_detail text not null,
    med_created_at timestamp not null default current_timestamp,
    med_update_at timestamp not null default current_timestamp on update current_timestamp,
    admin_ID int not null,
    foreign key(admin_ID) references admin(admin_ID)
);
